What's in the package:
1. mini-library-1.0: springboot backend
2. mini-library-1.0-front: springboot frontend
3. Screenshot-*.PNG: application screenshots
4. README.txt: this document

Instructions:
0. unzip mini-library-1.0-Lei.zip
1. unzip mini-library-1.0. And run: mvn install 
2. get toy-library-0.0.1-SNAPSHOT.jar from target folder 
3. run: java -jar toy-library-0.0.1-SNAPSHOT.jar
4. unzip mini-library-1.0-front.zip. And run: npm start
5. go to your favorite browser type http://localhost:4200
6. Enjoy!

Author: Lei Huang 
Email:  nicolas.818@gmail.com
